﻿namespace OHC.DLL.models
{
    public class SymptomAnswer
    {
        public int Id { get; set; }
        public int QuestionId { get; set; }
        public int UserId { get; set; }
        public string SelectedOption { get; set; } = string.Empty;
    }


}
