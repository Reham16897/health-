﻿namespace OHC.DLL.models
{
    public class DailyCalories
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime Date { get; set; }
        public int CaloriesConsumed { get; set; }
        public int CaloriesBurned { get; set; }
    }


}
