﻿namespace OHC.DLL.models

{
    public class SymptomQuestion
    {
        public int Id { get; set; }
        public string QuestionText { get; set; } = string.Empty;
        public List<string> Options { get; set; } = new();
    }


}
