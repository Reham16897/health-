﻿using System.Data;

namespace OHC.DLL.models

{
    public class UserProfile
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public int Age { get; set; }
        public double Weight { get; set; }
        public double Height { get; set; }
        public string Gender { get; set; } = string.Empty;

        public int RoleId { get; set; }
        public Role Role { get; set; }
    }


}
