﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OHC.DLL.models;
using OHC.DLL.Models;

namespace OHC.DLL.Data.Configurations
{
    public class SymptomAnswerConfiguration : IEntityTypeConfiguration<SymptomAnswer>
    {
        public void Configure(EntityTypeBuilder<SymptomAnswer> builder)
        {
            builder.ToTable("SymptomAnswers");
            builder.HasKey(a => a.Id);

            builder.Property(a => a.SelectedOption).HasMaxLength(200).IsRequired();

            builder.HasOne<SymptomQuestion>()
                   .WithMany()
                   .HasForeignKey(a => a.QuestionId)
                   .OnDelete(DeleteBehavior.Cascade);
        }
    }
}