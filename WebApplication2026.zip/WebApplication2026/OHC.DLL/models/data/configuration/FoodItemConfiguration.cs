﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OHC.DLL.models;
using OHC.DLL.Models;

namespace OHC.DLL.Data.Configurations
{
    public class FoodItemConfiguration : IEntityTypeConfiguration<FoodItem>
    {
        public void Configure(EntityTypeBuilder<FoodItem> builder)
        {
            builder.ToTable("FoodItems");
            builder.HasKey(f => f.Id);

            builder.Property(f => f.Name).HasMaxLength(200).IsRequired();
            builder.Property(f => f.Calories).IsRequired();
            builder.Property(f => f.Protein).HasColumnType("float");
            builder.Property(f => f.Carbs).HasColumnType("float");
            builder.Property(f => f.Fat).HasColumnType("float");
        }
    }
}