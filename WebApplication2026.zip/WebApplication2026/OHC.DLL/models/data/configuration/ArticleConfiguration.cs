﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OHC.DLL.models;
using OHC.DLL.Models;

namespace OHC.DLL.Data.Configurations
{
    public class ArticleConfiguration : IEntityTypeConfiguration<Article>
    {
        public void Configure(EntityTypeBuilder<Article> builder)
        {
            builder.ToTable("Articles");
            builder.HasKey(a => a.Id);

            builder.Property(a => a.Title).HasMaxLength(250).IsRequired();
            builder.Property(a => a.Content).HasColumnType("nvarchar(max)").IsRequired();
            builder.Property(a => a.ImageUrl).HasMaxLength(500);
        }
    }
}