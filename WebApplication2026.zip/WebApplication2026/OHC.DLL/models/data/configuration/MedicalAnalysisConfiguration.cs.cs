﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OHC.DLL.models;
using OHC.DLL.Models;

namespace OHC.DLL.Data.Configurations
{
    public class MedicalAnalysisConfiguration : IEntityTypeConfiguration<MedicalAnalysis>
    {
        public void Configure(EntityTypeBuilder<MedicalAnalysis> builder)
        {
            builder.ToTable("MedicalAnalyses");
            builder.HasKey(ma => ma.Id);

            builder.Property(ma => ma.Result).HasMaxLength(50).IsRequired();
            builder.Property(ma => ma.SugarLevel).HasColumnType("float");
            builder.Property(ma => ma.CholesterolLevel).HasColumnType("float");
            builder.Property(ma => ma.BloodPressure).HasColumnType("float");

            builder.HasOne<UserProfile>()
                   .WithMany()
                   .HasForeignKey(ma => ma.UserId)
                   .OnDelete(DeleteBehavior.Cascade);
        }
    }
}