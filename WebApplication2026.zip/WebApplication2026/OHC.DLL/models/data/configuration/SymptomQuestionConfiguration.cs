﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using OHC.DLL.models;
using OHC.DLL.Models;
using System.Text.Json;

namespace OHC.DLL.Data.Configurations
{
    public class SymptomQuestionConfiguration : IEntityTypeConfiguration<SymptomQuestion>
    {
        public void Configure(EntityTypeBuilder<SymptomQuestion> builder)
        {
            builder.ToTable("SymptomQuestions");
            builder.HasKey(q => q.Id);

            builder.Property(q => q.QuestionText).HasMaxLength(500).IsRequired();

            var converter = new ValueConverter<List<string>, string>(
                v => JsonSerializer.Serialize(v, (JsonSerializerOptions)null),
                v => JsonSerializer.Deserialize<List<string>>(v, (JsonSerializerOptions)null) ?? new List<string>()
            );

            builder.Property(q => q.Options).HasConversion(converter).HasColumnType("nvarchar(max)");
        }
    }
}