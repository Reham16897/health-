﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OHC.DLL.models;
using OHC.DLL.Models;

namespace OHC.DLL.Data.Configurations
{
    public class DailyCaloriesConfiguration : IEntityTypeConfiguration<DailyCalories>
    {
        public void Configure(EntityTypeBuilder<DailyCalories> builder)
        {
            builder.ToTable("DailyCalories");
            builder.HasKey(dc => dc.Id);

            builder.Property(dc => dc.Date).IsRequired();
            builder.Property(dc => dc.CaloriesConsumed).IsRequired();
            builder.Property(dc => dc.CaloriesBurned).IsRequired();

            builder.HasOne<UserProfile>()
                   .WithMany()
                   .HasForeignKey(dc => dc.UserId)
                   .OnDelete(DeleteBehavior.Cascade);
        }
    }
}