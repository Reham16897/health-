﻿using Microsoft.EntityFrameworkCore;
using OHC.DLL.Data.Configurations;
using OHC.DLL.models;
using OHC.DLL.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace OHC.DLL.Data
{
    public class HealthDbContext : DbContext
    {
        public HealthDbContext(DbContextOptions<HealthDbContext> options) : base(options) { }

        public DbSet<UserProfile> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Article> Articles { get; set; }
        public DbSet<SymptomQuestion> SymptomQuestions { get; set; }
        public DbSet<SymptomAnswer> SymptomAnswers { get; set; }
        public DbSet<DailyCalories> DailyCalories { get; set; }
        public DbSet<FoodItem> FoodItems { get; set; }
        public DbSet<MedicalAnalysis> MedicalAnalyses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new UserProfileConfiguration());
            modelBuilder.ApplyConfiguration(new RoleConfiguration());
            modelBuilder.ApplyConfiguration(new ArticleConfiguration());
            modelBuilder.ApplyConfiguration(new SymptomQuestionConfiguration());
            modelBuilder.ApplyConfiguration(new SymptomAnswerConfiguration());
            modelBuilder.ApplyConfiguration(new DailyCaloriesConfiguration());
            modelBuilder.ApplyConfiguration(new FoodItemConfiguration());
            modelBuilder.ApplyConfiguration(new MedicalAnalysisConfiguration());

            // Seed Roles
            modelBuilder.Entity<Role>().HasData(
                new Role { Id = 1, Name = "Admin" },
                new Role { Id = 2, Name = "User" }
            );
        }
    }
}