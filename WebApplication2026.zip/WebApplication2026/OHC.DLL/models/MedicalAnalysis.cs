﻿namespace OHC.DLL.models

{
    public class MedicalAnalysis
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public double SugarLevel { get; set; }
        public double CholesterolLevel { get; set; }
        public double BloodPressure { get; set; }
        public string Result { get; set; } = string.Empty; // عالي - متوسط - منخفض
    }


}
