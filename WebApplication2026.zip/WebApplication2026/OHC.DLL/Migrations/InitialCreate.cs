﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OHC.DLL.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // جدول Roles
            migrationBuilder.CreateTable(
                name: "Roles",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Roles", x => x.Id);
                });

            // جدول Users
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FullName = table.Column<string>(maxLength: 200, nullable: false),
                    Email = table.Column<string>(maxLength: 200, nullable: false),
                    PasswordHash = table.Column<string>(maxLength: 256, nullable: false),
                    Age = table.Column<int>(nullable: false),
                    Weight = table.Column<double>(nullable: false),
                    Height = table.Column<double>(nullable: false),
                    Gender = table.Column<string>(maxLength: 20, nullable: true),
                    RoleId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Users_Roles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "Roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Users_Email",
                table: "Users",
                column: "Email",
                unique: true);

            // جدول Articles
            migrationBuilder.CreateTable(
                name: "Articles",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(maxLength: 250, nullable: false),
                    Content = table.Column<string>(nullable: false),
                    ImageUrl = table.Column<string>(maxLength: 500, nullable: true),
                    PublishedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Articles", x => x.Id);
                });

            // جدول SymptomQuestions
            migrationBuilder.CreateTable(
                name: "SymptomQuestions",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionText = table.Column<string>(maxLength: 500, nullable: false),
                    Options = table.Column<string>(nullable: true) // مخزنة كـ JSON
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SymptomQuestions", x => x.Id);
                });

            // جدول SymptomAnswers
            migrationBuilder.CreateTable(
                name: "SymptomAnswers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionId = table.Column<int>(nullable: false),
                    UserId = table.Column<int>(nullable: false),
                    SelectedOption = table.Column<string>(maxLength: 200, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SymptomAnswers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SymptomAnswers_SymptomQuestions_QuestionId",
                        column: x => x.QuestionId,
                        principalTable: "SymptomQuestions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            // جدول DailyCalories
            migrationBuilder.CreateTable(
                name: "DailyCalories",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    Date = table.Column<DateTime>(nullable: false),
                    CaloriesConsumed = table.Column<int>(nullable: false),
                    CaloriesBurned = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DailyCalories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DailyCalories_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            // جدول FoodItems
            migrationBuilder.CreateTable(
                name: "FoodItems",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(maxLength: 200, nullable: false),
                    Calories = table.Column<int>(nullable: false),
                    Protein = table.Column<double>(nullable: false),
                    Carbs = table.Column<double>(nullable: false),
                    Fat = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FoodItems", x => x.Id);
                });

            // جدول MedicalAnalyses
            migrationBuilder.CreateTable(
                name: "MedicalAnalyses",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(nullable: false),
                    SugarLevel = table.Column<double>(nullable: false),
                    CholesterolLevel = table.Column<double>(nullable: false),
                    BloodPressure = table.Column<double>(nullable: false),
                    Result = table.Column<string>(maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MedicalAnalyses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MedicalAnalyses_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(name: "Articles");
            migrationBuilder.DropTable(name: "DailyCalories");
            migrationBuilder.DropTable(name: "FoodItems");
            migrationBuilder.DropTable(name: "MedicalAnalyses");
            migrationBuilder.DropTable(name: "SymptomAnswers");
            migrationBuilder.DropTable(name: "SymptomQuestions");
            migrationBuilder.DropTable(name: "Users");
            migrationBuilder.DropTable(name: "Roles");
        }
    }
}