﻿namespace OHC.DLL.models
    using OHC.DLL.Data;
using OHC.DLL.Models;
using Microsoft.EntityFrameworkCore;

namespace OHC.BLL.Services
{
    public interface IFoodService
    {
        Task<FoodItem?> GetByNameAsync(string name);
        Task<List<FoodItem>> GetAllAsync();
    }

    public class FoodService : IFoodService
    {
        private readonly HealthDbContext _db;

        public FoodService(HealthDbContext db) => _db = db;

        public async Task<FoodItem?> GetByNameAsync(string name)
        {
            return await _db.FoodItems.FirstOrDefaultAsync(f => f.Name == name);
        }

        public async Task<List<FoodItem>> GetAllAsync() => await _db.FoodItems.ToListAsync();
    }
}