﻿using OHC.BLL.DataTransFerObjects.UserDtos;
using OHC.DLL.Data;
using OHC.DLL.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace OHC.BLL.Services
{
    public interface IAuthService
    {
        Task<UserProfile?> LoginAsync(UserAuthDto dto);
        Task<bool> RegisterAsync(UserAuthDto dto, string fullName, int roleId = 2);
    }

    public class AuthService : IAuthService
    {
        private readonly HealthDbContext _db;

        public AuthService(HealthDbContext db) => _db = db;

        public async Task<UserProfile?> LoginAsync(UserAuthDto dto)
        {
            var hashed = Hash(dto.Password);
            return await _db.Users.Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.Email == dto.Email && u.PasswordHash == hashed);
        }

        public async Task<bool> RegisterAsync(UserAuthDto dto, string fullName, int roleId = 2)
        {
            if (await _db.Users.AnyAsync(u => u.Email == dto.Email)) return false;

            var user = new UserProfile
            {
                FullName = fullName,
                Email = dto.Email,
                PasswordHash = Hash(dto.Password),
                RoleId = roleId
            };

            _db.Users.Add(user);
            await _db.SaveChangesAsync();
            return true;
        }

        private string Hash(string input)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
            return Convert.ToHexString(bytes);
        }
    }
}