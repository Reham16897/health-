﻿using OHC.DLL.Data;
using OHC.DLL.Models;
using Microsoft.EntityFrameworkCore;

namespace OHC.BLL.Services
{
    public interface IAnalysisService
    {
        Task<MedicalAnalysis?> GetByUserAsync(int userId);
        Task SaveAsync(MedicalAnalysis analysis);
    }

    public class AnalysisService : IAnalysisService
    {
        private readonly HealthDbContext _db;

        public AnalysisService(HealthDbContext db) => _db = db;

        public async Task<MedicalAnalysis?> GetByUserAsync(int userId)
        {
            return await _db.MedicalAnalyses.FirstOrDefaultAsync(ma => ma.UserId == userId);
        }

        public async Task SaveAsync(MedicalAnalysis analysis)
        {
            var existing = await GetByUserAsync(analysis.UserId);
            if (existing != null)
            {
                existing.SugarLevel = analysis.SugarLevel;
                existing.CholesterolLevel = analysis.CholesterolLevel;
                existing.BloodPressure = analysis.BloodPressure;
                existing.Result = analysis.Result;
            }
            else
            {
                _db.MedicalAnalyses.Add(analysis);
            }
            await _db.SaveChangesAsync();
        }
    }
}