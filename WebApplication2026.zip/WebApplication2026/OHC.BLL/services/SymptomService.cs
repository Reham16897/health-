﻿using OHC.DLL.Data;
using OHC.DLL.Models;
using Microsoft.EntityFrameworkCore;

namespace OHC.BLL.Services
{
    public interface ISymptomService
    {
        Task<List<SymptomQuestion>> GetQuestionsAsync();
        Task SaveAnswerAsync(SymptomAnswer answer);
    }

    public class SymptomService : ISymptomService
    {
        private readonly HealthDbContext _db;

        public SymptomService(HealthDbContext db) => _db = db;

        public async Task<List<SymptomQuestion>> GetQuestionsAsync() => await _db.SymptomQuestions.ToListAsync();

        public async Task SaveAnswerAsync(SymptomAnswer answer)
        {
            _db.SymptomAnswers.Add(answer);
            await _db.SaveChangesAsync();
        }
    }
}