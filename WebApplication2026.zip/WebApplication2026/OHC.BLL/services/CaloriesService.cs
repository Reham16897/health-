﻿using OHC.DLL.Data;
using OHC.DLL.Models;
using Microsoft.EntityFrameworkCore;

namespace OHC.BLL.Services
{
    public interface ICaloriesService
    {
        Task<DailyCalories?> GetByDateAsync(int userId, DateTime date);
        Task AddOrUpdateAsync(DailyCalories dailyCalories);
    }

    public class CaloriesService : ICaloriesService
    {
        private readonly HealthDbContext _db;

        public CaloriesService(HealthDbContext db) => _db = db;

        public async Task<DailyCalories?> GetByDateAsync(int userId, DateTime date)
        {
            return await _db.DailyCalories.FirstOrDefaultAsync(dc => dc.UserId == userId && dc.Date == date);
        }

        public async Task AddOrUpdateAsync(DailyCalories dailyCalories)
        {
            var existing = await GetByDateAsync(dailyCalories.UserId, dailyCalories.Date);
            if (existing != null)
            {
                existing.CaloriesConsumed = dailyCalories.CaloriesConsumed;
                existing.CaloriesBurned = dailyCalories.CaloriesBurned;
            }
            else
            {
                _db.DailyCalories.Add(dailyCalories);
            }
            await _db.SaveChangesAsync();
        }
    }
}