﻿using Microsoft.EntityFrameworkCore;
using OHC.DLL.Data;
using OHC.DLL.models;
using OHC.DLL.Models;

namespace OHC.BLL.Services
{
    public interface IArticleService
    {
        Task<List<Article>> GetAllAsync();
        Task<Article?> GetByIdAsync(int id);
        Task AddAsync(Article article);
    }

    public class ArticleService : IArticleService
    {
        private readonly HealthDbContext _db;

        public ArticleService(HealthDbContext db) => _db = db;

        public async Task<List<Article>> GetAllAsync() => await _db.Articles.ToListAsync();

        public async Task<Article?> GetByIdAsync(int id) => await _db.Articles.FindAsync(id);

        public async Task AddAsync(Article article)
        {
            _db.Articles.Add(article);
            await _db.SaveChangesAsync();
        }
    }
}