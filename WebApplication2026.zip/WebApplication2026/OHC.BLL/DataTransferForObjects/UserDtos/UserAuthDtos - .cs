﻿using System;

namespace OHC.BLL.DataTransFerObjects.UserDtos
{
    public class UserAuthDto
    {
        public int UserId { get; set; } // pk
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;

        public DateOnly CreatedOn { get; set; }
        public bool IsActive { get; set; }
    }
}

