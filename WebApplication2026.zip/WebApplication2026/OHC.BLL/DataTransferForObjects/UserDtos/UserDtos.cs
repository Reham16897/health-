﻿using System;

namespace OHC.BLL.DataTransFerObjects.UserDtos
{
    public class UserProfileDetailsDto
    {
        public int Id { get; set; } // pk
        public int CreatedBy { get; set; } // admin id
        public DateOnly CreatedOn { get; set; }

        public int LastModifiedBy { get; set; }
        public DateOnly LastModifiedOn { get; set; }
        public bool IsDeleted { get; set; }

        public string FullName { get; set; } = string.Empty;
        public int Age { get; set; }
        public double Weight { get; set; }
        public double Height { get; set; }
        public string Gender { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}
