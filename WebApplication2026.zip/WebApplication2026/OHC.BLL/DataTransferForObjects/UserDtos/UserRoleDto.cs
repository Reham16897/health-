﻿namespace OHC.BLL.DataTransFerObjects.UserDtos
{
    public class UserRoleDto
    {
        public int UserId { get; set; }
        public string RoleName { get; set; } = string.Empty; // Admin, User
    }
}