﻿namespace WebApplication2026.Models
{
    public class Moive
    {
    }
}
