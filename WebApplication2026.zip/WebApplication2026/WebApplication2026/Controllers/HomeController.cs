﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2026.Controllers
{
    public class HomeController : Controller
    {
        //BaseURL/Home/Index
        public IActionResult Index()
        {
            return View();// Return Viwe With Same Name Of Action
        }
        //BaesURL/Home/Privacy
        public IActionResult CalorisAndFoodTracer()
        {
            return View();
           

        }
        //BaesURL/Home/SyptomChecker
        public IActionResult SypmtomChecker()
        {
            return View();


        }
        public IActionResult MedicalAnalysis()
        {
            return View();


        }

    }
}
