﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2026.Controllers
{
    public class AccountController: Controller
    {
        //BaseURL/Account/SignIn
        public IActionResult SignIn()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
    }
}
