﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2026.Controllers
{

    public class moviseControllers : Controller
    { 
        
    }
}
